package gruppenarbeit.statischesSystem;
import gruppenarbeit.kraefte.Einzellast;

//gets data as fachwert
public class Kragtraeger {
    double _l,  //laenge
            _mMax, //maxBiegemoment
            _p, //Einzellast --> needed for
            _xa; //

    public Kragtraeger(double l, double p, double xa){
        //set variables for safety
        _l = l;
        _p = p;
        _xa = xa;

        //new Einzellast object with values given
        Einzellast elsa = new Einzellast(_p, _xa);
        //objects calculate
        set_mMax(elsa.berechneMmax());
    }
    //getter methods in this case probably obsolete

    //setter
    public void set_mMax(double _mMax) {
        this._mMax = _mMax;
    }

    public void set_l(double _l) {
        this._l = _l;
    }

    public void set_p(double _p) {
        this._p = _p;
    }

    public void set_xa(double _xa) {
        this._xa = _xa;
    }
}
