package gruppenarbeit.ausgabe;

import javax.swing.*;

public class lab {
    private JPanel panel1;
}
