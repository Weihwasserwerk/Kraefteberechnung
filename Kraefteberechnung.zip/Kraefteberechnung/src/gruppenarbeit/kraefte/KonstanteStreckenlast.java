package gruppenarbeit.kraefte;

//uselass class, not in use once and could be a security risk
public class KonstanteStreckenlast extends Last {
    double Xa, Xb;

    @Override
    public double berechneMmax() {
        return 0;
    }
}
