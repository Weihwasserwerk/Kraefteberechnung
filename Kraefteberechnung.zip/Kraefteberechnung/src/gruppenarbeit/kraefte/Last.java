package gruppenarbeit.kraefte;

//fachwerte
abstract class Last {
    double _wert;
    public abstract double berechneMmax();

    public void set_wert(double a){
        _wert = a;
    }
}

